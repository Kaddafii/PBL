const express = require("express");
const mysql = require("mysql");
const ejs = require("ejs");

const app = express();

app.set("view engine", "ejs");
app.set("views", "views");

const db = mysql.createConnection({
  host: "localhost",
  database: "akun_pengguna",
  user: "root",
  password: "",
});

db.connect((err) => {
  if (err) throw err;
  console.log("Database connected....");
});

app.use(express.urlencoded({ extended: false }));

app.get("/", (req, res) => {
  res.render("index", { title: "Home" });
});

app.get("/login", (req, res) => {
  res.render("login", { title: "Login" });
});

app.post("/login", (req, res) => {
  const { email, password } = req.body;
  const sql = "SELECT * FROM pengguna WHERE email = ? AND password = ?";
  db.query(sql, [email, password], (err, results) => {
    if (err) {
      console.log(err);
      res.send("Error occurred during login.");
    } else {
      if (results.length > 0) {
        res.send("Login successful!");
      } else {
        res.send("Invalid email or password.");
      }
    }
  });
});

app.get("/register", (req, res) => {
  res.render("register", { title: "Register" });
});

app.post("/register", (req, res) => {
  const { email, password } = req.body;

  const sql = "INSERT INTO pengguna (email, password) VALUES (?, ?)";
  db.query(sql, [email, password], (err, result) => {
    if (err) {
      console.log(err);
      res.send("Error occurred during registration.");
    } else {
      res.send("Registration successful!");
    }
  });
});

app.listen(8000, () => {
  console.log("Server ready....");
});
